package com.jsp;

public class Bank 
{
   String bname;
   String loc;
   String ifsc_code;
   
   Account e;
   
public Bank(String bname, String loc, String ifsc_code) 
{
	this.bname = bname;
	this.loc = loc;
	this.ifsc_code = ifsc_code;
}
  
 public void createAccount(Account e)
 {
	 if(this.e==null)
	 {
		 this.e=e;
		 System.out.println("Account Successfully Created");
	 }
	 else
	 {
		 System.out.println("Account is already exist");
	 }
 }
 
 public void checkDetails()
 {
	 if(this.e!=null)
	 {
	   System.out.println(e.dob);
	   System.out.println(e.name);
	   System.out.println(e.money);
	   System.out.println(e.pin);
	   System.out.println(e.accno);
	 }
	 else
	 {
		 System.out.println("Account is not present");
	 }
 }
 
 public void depositeMoney(String accno,double money)
 {
   if(this.e!=null)
	{
	 if(e.accno.equals(accno))
	 {
		 if(this.e.money!=0)
		 {
			 e.money = e.money + money;
			 System.out.println("Deposit amount is : "+money);
			 System.out.println("Total amount is : "+ e.money);
		 }
		 else
		 {
			 System.out.println("Enter valid amount");
		 }
	 }
	 else
	 {
		 System.out.println("Enter valid accno");
	 }
	}
   else
   {
	   System.out.println("Create Account First");
   }
 }
 
 public void withdrawMoney(String accno,double money)
 {
   if(this.e!=null)
   {
	 if(e.accno.equals(accno))
	 {
		 if(e.money>=money)
		 {
			 e.money = e.money - money;
			 System.out.println("Withdarw amount is : "+money);
			 System.out.println("Total amount is : "+e.money);
		 }
		 else
		 {
			 System.out.println("Insufficient balance");
		 }
	 }
	 else
	 {
		 System.out.println("Enter a valid accno");
	 }
   }
   else
   {
	   System.out.println("Create Account first");
   }
 }
 
 public void deleteAccount()
 {
	 if(this.e==null)
	 {
		 System.out.println("Create Account first");
	 }
	 if(this.e!=null)
	 {
		 System.out.println("Account is deleted");
	 }
	 this.e=null;
 }
 
 
}
