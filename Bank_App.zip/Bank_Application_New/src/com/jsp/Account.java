package com.jsp;

public class Account 
{
   String name;
   String dob;
   String pin;
   double money;
   String accno;
   
public Account(String name, String dob, String pin, double money, String accno) 
{
	this.name = name;
	this.dob = dob;
	this.pin = pin;
	this.money = money;
	this.accno = accno;
}
   
   
}
