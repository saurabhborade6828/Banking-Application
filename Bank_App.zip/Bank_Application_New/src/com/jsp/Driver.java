package com.jsp;

import java.util.Scanner;

public class Driver 
{  
   public static void main(String[] args) 
   {
	  try
	  {
	  Scanner sc = new Scanner(System.in);
	  System.out.println("Enter the bank name to open account");
	  String bname = sc.next();
	  System.out.println("Enter bank location");
	  String loc = sc.next();
	  System.out.println("Enter bank IFSC Code");
	  String ifsc_code = sc.next();
	  
	  Bank bank = new Bank(bname, loc, ifsc_code);
	  
	  boolean option = true;
	  while(option)
	  {
		  System.out.println("Enter your choice");
		  System.out.println("Enter 1 for : CREATE ACCOUNT");
		  System.out.println("Enter 2 for : CHECK DETAILS");
		  System.out.println("Enter 3 for : DEPOSIT MONEY");
		  System.out.println("Enter 4 for : WITHDRAWL");
		  System.out.println("Enter 5 for : DELETE ACCOUNT");
		  System.out.println("Enter 6 for : EXIT OR CLOSE APPLICATION");
		  
		  int choice  = sc.nextInt();
		  switch(choice) 
		  {
		    case 1 : {
		    	System.out.println("Enter your name");
		    	String name = sc.next();
		    	System.out.println("Enter your dob");
		    	String dob = sc.next();
		    	System.out.println("Enter your pin");
		    	String pin = sc.next();
		    	System.out.println("Enter your money");
		    	double money = sc.nextDouble();
		    	System.out.println("Enter your accno");
		    	String accno = sc.next();
		    	bank.createAccount(new Account(name, dob, pin, money, accno));
		    	System.out.println("==========================================");
		    	
		    }
			break;
			
		    case 2: {
		    	bank.checkDetails();
		    	System.out.println("==========================================");
		    }
			break;
			
		    case 3: {
		    	System.out.println("Enter the accno to deposit money");
		    	String accno = sc.next();
		    	System.out.println("Enter the money you want to deposit");
		    	double money = sc.nextDouble();
		    	bank.depositeMoney(accno, money);
		    	System.out.println("==========================================");
		    }
			break;
			
		    case 4: {
		    	System.out.println("Enter the accno to withdraw money");
		    	String accno = sc.next();
		    	System.out.println("Enter the money you want to withdraw");
		    	double money = sc.nextDouble();
		    	bank.withdrawMoney(accno, money);
		    	System.out.println("==========================================");
		    }
			break;
			
		    case 5: {
		    	bank.deleteAccount();
		    	System.out.println("==========================================");
		    }
			break;
			
		    case 6: {
		    	System.out.println("Thank for using "+bank.bname);
		    	System.out.println("Have a Good Day!!!");
		    	option = false;
		    	System.out.println("==========================================");
		    }
			break;

		default: {
			System.out.println("Enter valid choice");
		  }
			break;
		 }
	   }
	 }
	  catch (Exception e) 
	  {
		 System.out.println("Input Mismatch");
	  }
   }
}
